﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RepairCenter
{
    /// <summary>
    /// Логика взаимодействия для Orders.xaml
    /// </summary>
    public partial class Orders : Window
    {
        RepairCenterEntities1 db = new RepairCenterEntities1();
        List<Сотрудники> masters = new List<Сотрудники>();
        List<Заявки> orders = new List<Заявки>();
        List<Статус> status = new List<Статус>();
        Заявки order;
        public Orders()
        {
            InitializeComponent();
            masters = db.Сотрудники.Where(x => x.Тип_Пользователя == 2).ToList();
            orders = db.Заявки.ToList();
            status = db.Статус.ToList();
            
            for(int i = 0; i < masters.Count; i++)
            {
                Masters.Items.Add(masters[i].Фамилия + " " + masters[i].Имя);
            }

            Status.Items.Add("Без фильтра");
            for (int i = 0; i < status.Count; i++)
            {
                Status.Items.Add(status[i].Наименование);
            }
            Status.SelectedItem = 0;
            for (int i = 0; i < orders.Count; i++)
            {
                WrapPanel wp = new WrapPanel();
                Label lb = new Label();

                lb.Content = "Номер заявки: " + orders[i].id;
                lb.Uid = orders[i].id.ToString();
                wp.Uid = orders[i].id.ToString();
                wp.Children.Add(lb);
                listOrders.Items.Add(wp);

            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)//Добавить
        {
            int id = listOrders.SelectedIndex + 1;

            if (id != 0)
            {
                Сотрудники master = db.Сотрудники.FirstOrDefault(x => x.Фамилия + " " + x.Имя == Masters.Text);
                order.Сотрудники = master.id;
                db.SaveChanges();
                MessageBox.Show("Мастер добавлен в заявку!");
            }
            else
                MessageBox.Show("Выберите заказ!");
        }

        private void Status_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            FilterList();
        }

        private void FilterList()
        {
            listOrders.Items.Clear();
            int id = Status.SelectedIndex;
            if (id != 0)
            {
                string stat = status[id - 1].Наименование;
                List<Заявки> ordersNew = db.Заявки.Where(x => x.Статус1.Наименование == stat).ToList();
                if (ordersNew.Count != 0)
                {
                    for (int i = 0; i < ordersNew.Count; i++)
                    {
                        WrapPanel wp = new WrapPanel();
                        Label lb = new Label();

                        lb.Content = "Номер заявки: " + ordersNew[i].id;
                        lb.Uid = ordersNew[i].id.ToString();
                        wp.Uid = ordersNew[i].id.ToString();
                        wp.Children.Add(lb);
                        listOrders.Items.Add(wp);

                    }
                }
            }
            else
            {
                for (int i = 0; i < orders.Count; i++)
                {
                    WrapPanel wp = new WrapPanel();
                    Label lb = new Label();

                    lb.Content = "Номер заявки: " + orders[i].id;
                    lb.Uid = orders[i].id.ToString();
                    wp.Uid = orders[i].id.ToString();
                    wp.Children.Add(lb);
                    listOrders.Items.Add(wp);

                }
            }
        }

        private void listOrders_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            WrapPanel wp = (WrapPanel)listOrders.SelectedItem;
            if (wp != null) 
            {
                int id = Convert.ToInt32(wp.Uid);

                order = orders.Find(x => x.id == id);
                if (order != null)
                {
                    FIO.Content = order.Пользователи.Фамилия + " " + order.Пользователи.Имя + " " + order.Пользователи.Отчество;
                    Discription.Text = order.Описание_проблемы;

                    if (order.Сотрудники != null)
                        Masters.SelectedIndex = order.id - 1;
                }
            }
        }
    }
}
