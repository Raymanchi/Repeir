﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation.Peers;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RepairCenter
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        RepairCenterEntities1 db = new RepairCenterEntities1();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)//Авторизация
        {
            Пользователи user = db.Пользователи.Where(x => x.Логин == Login.Text && x.Пароль == Password.Text).FirstOrDefault();
            Сотрудники employee = db.Сотрудники.Where(x => x.Логин == Login.Text && x.Пароль == Password.Text).FirstOrDefault();
            if (user != null)
            {
                UserWindow uw = new UserWindow(user);
                uw.Show();
                Close();
            }
            else if (employee != null)
            {
                if (employee.Тип_Пользователя == 1)
                {
                    ManagerWindow mw = new ManagerWindow(employee);
                    mw.Show();
                    Close();
                }
                else if (employee.Тип_Пользователя == 2)
                {
                    MasterWindow mw = new MasterWindow(employee);
                    mw.Show();
                    Close();
                }
            }
            else
                MessageBox.Show("Логин или пароль неверны!");
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)//Регистрация
        {
            try 
            {
                if (SecondName.Text != "" &&
                    FirstName.Text != "" &&
                    FatherName.Text != "" &&
                    Phone.Text != "" &&
                    LoginReg.Text != "")
                {
                    if (CheckPassword(PasswordReg.Text))
                    {
                        int numbTest = Convert.ToInt32(Phone.Text);
                        Пользователи user = new Пользователи
                        {
                            Фамилия = SecondName.Text,
                            Имя = FirstName.Text,
                            Отчество = FatherName.Text,
                            Номер_Телефона = Phone.Text,
                            Логин = LoginReg.Text,
                            Пароль = PasswordReg.Text
                        };
                        db.Пользователи.Add(user);
                        db.SaveChanges();
                    }
                    else
                        MessageBox.Show("Введите пароль по правилам!");
                }
                else
                    MessageBox.Show("Вы не ввели информацию!");
            }
            catch
            {
                MessageBox.Show("Введите номер телефона корректно! Не используйте знаки \"+\" ");
            }
        }
        public static bool CheckPassword(string password)
        {
            Regex validatePasswordRegex = new Regex("^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$");
            return validatePasswordRegex.IsMatch(password);
        }
    }
}
