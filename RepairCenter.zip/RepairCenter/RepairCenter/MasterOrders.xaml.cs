﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Management.Instrumentation;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RepairCenter
{
    /// <summary>
    /// Логика взаимодействия для MasterOrders.xaml
    /// </summary>
    public partial class MasterOrders : Window
    {
        RepairCenterEntities1 db = new RepairCenterEntities1();
        List<Заявки> orders = new List<Заявки>();
        List<Статус> status = new List<Статус>();
        Заявки order;
        Сотрудники employee;
        public MasterOrders(Сотрудники employee)
        {
            InitializeComponent();
            this.employee = employee;
            orders = db.Заявки.Where(x => x.Сотрудники == employee.id).ToList();
            status = db.Статус.ToList();

            for (int i = 0; i < orders.Count; i++)
            {
                WrapPanel wp = new WrapPanel();
                Label lb = new Label();

                lb.Content = "Номер заявки: " + orders[i].id;
                lb.Uid = orders[i].id.ToString();
                lb.Uid = orders[i].id.ToString();
                wp.Children.Add(lb);
                listOrders.Items.Add(wp);

            }

            for (int i = 0; i < status.Count; i++) 
            { 
                Status.Items.Add(status[i].Наименование);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)//Изменение статуса
        {
            if (order != null)
            {
                order.Статус = Status.SelectedIndex + 1;
                db.SaveChanges();
                MessageBox.Show("Статус успешно изменен!");
            }
            else
                MessageBox.Show("Выберите заявку!");
        }

        private void listOrders_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            WrapPanel wp = (WrapPanel)listOrders.SelectedItem;
            if (wp != null) 
            {
                int id = Convert.ToInt32(wp.Uid);

                order = orders.Find(x => x.id == id);
                FIO.Content = order.Пользователи.Фамилия + " " + order.Пользователи.Имя + " " + order.Пользователи.Отчество;
                Discription.Text = order.Описание_проблемы;

                if (order.Сотрудники != null)
                    Status.SelectedIndex = order.id - 1;
            }
        }
    }
}
