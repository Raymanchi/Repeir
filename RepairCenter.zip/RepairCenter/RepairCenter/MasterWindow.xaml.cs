﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RepairCenter
{
    /// <summary>
    /// Логика взаимодействия для MasterWindow.xaml
    /// </summary>
    public partial class MasterWindow : Window
    {
        RepairCenterEntities1 db = new RepairCenterEntities1();
        Сотрудники employee;
        public MasterWindow(Сотрудники employee)
        {
            InitializeComponent();
            this.employee = employee;
        }

        private void Button_Click(object sender, RoutedEventArgs e)//Заявки
        {
            MasterOrders mo = new MasterOrders(employee);
            mo.Show();
            Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            Close();
        }
    }
}
