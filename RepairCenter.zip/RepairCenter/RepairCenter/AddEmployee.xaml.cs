﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RepairCenter
{
    /// <summary>
    /// Логика взаимодействия для AddEmployee.xaml
    /// </summary>
    public partial class AddEmployee : Window
    {
        RepairCenterEntities1 db = new RepairCenterEntities1();
        Сотрудники employee;
        public AddEmployee(Сотрудники employee)
        {
            InitializeComponent();
            this.employee = employee;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (SecondName.Text != "" &&
                FirstName.Text != "" &&
                FatherName.Text != "" &&
                LoginReg.Text != "" &&
                MainWindow.CheckPassword(PasswordReg.Text))
            {
                Сотрудники NewEmployee = new Сотрудники 
                {
                    Фамилия = SecondName.Text,
                    Имя = FirstName.Text,
                    Отчество = FatherName.Text,
                    Логин = LoginReg.Text,
                    Пароль = PasswordReg.Text,
                    Тип_Пользователя = 2
                };
                db.Сотрудники.Add(NewEmployee);
                db.SaveChanges();
                MessageBox.Show($"Сотрудник {SecondName.Text} {FirstName.Text} успешно добавлен!");

                ManagerWindow mw = new ManagerWindow(employee);
                mw.Show();
                Close();
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            ManagerWindow mw = new ManagerWindow(employee);
        }
    }
}
