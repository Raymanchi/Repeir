﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RepairCenter
{
    /// <summary>
    /// Логика взаимодействия для ManagerWindow.xaml
    /// </summary>
    public partial class ManagerWindow : Window
    {
        RepairCenterEntities1 db = new RepairCenterEntities1();
        Сотрудники employee;
        public ManagerWindow(Сотрудники employee)
        {
            InitializeComponent();
            this.employee = employee;
        }

        private void Button_Click(object sender, RoutedEventArgs e)//Список заявок
        {
            Orders o = new Orders();
            o.Show();
            Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)//Добавить сотрудника
        {
            AddEmployee ae = new AddEmployee(employee);
            ae.Show();
            Close();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)//Выйти
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            Close();
        }
    }
}
