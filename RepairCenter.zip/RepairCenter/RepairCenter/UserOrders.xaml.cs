﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace RepairCenter
{
    /// <summary>
    /// Логика взаимодействия для UserOrders.xaml
    /// </summary>
    public partial class UserOrders : Window
    {
        RepairCenterEntities1 db = new RepairCenterEntities1();
        List<Заявки> orders = new List<Заявки>();
        List<Статус> status = new List<Статус>();
        Заявки order = new Заявки();
        Пользователи user;
        public UserOrders(Пользователи user)
        {
            InitializeComponent();
            this.user = user;
            orders = db.Заявки.Where(x => x.Клиент == user.id).ToList();
            status = db.Статус.ToList();

            Status.Items.Add("Без фильтра");
            for (int i = 0; i < status.Count; i++)
            {
                Status.Items.Add(status[i].Наименование);
            }

            for (int i = 0; i < orders.Count; i++)
            {
                WrapPanel wp = new WrapPanel();
                Label lb = new Label();

                lb.Content = "Номер заявки: " + orders[i].id;
                lb.Uid = orders[i].id.ToString();
                wp.Uid = orders[i].id.ToString();
                wp.Children.Add(lb);
                listOrders.Items.Add(wp);

            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)//Вернутся назад
        {
            UserWindow uw = new UserWindow(user);
            uw.Show();
            Close();
        }

        private void Status_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            FilterList();
        }

        private void FilterList()
        {
            listOrders.Items.Clear();
            int id = Status.SelectedIndex;
            if (id != 0)
            {
                string stat = status[id - 1].Наименование;
                List<Заявки> ordersNew = orders.FindAll(x => x.Статус1.Наименование == stat).ToList();
                if (ordersNew.Count != 0)
                {
                    for (int i = 0; i < ordersNew.Count; i++)
                    {
                        WrapPanel wp = new WrapPanel();
                        Label lb = new Label();

                        lb.Content = "Номер заявки: " + ordersNew[i].id;
                        lb.Uid = ordersNew[i].id.ToString();
                        wp.Uid = ordersNew[i].id.ToString();
                        wp.Children.Add(lb);
                        listOrders.Items.Add(wp);

                    }
                }
            }
            else
            {
                for (int i = 0; i < orders.Count; i++)
                {
                    WrapPanel wp = new WrapPanel();
                    Label lb = new Label();

                    lb.Content = "Номер заявки: " + orders[i].id;
                    lb.Uid = orders[i].id.ToString();
                    wp.Uid = orders[i].id.ToString();
                    wp.Children.Add(lb);
                    listOrders.Items.Add(wp);

                }
            }
        }

        private void listOrders_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            WrapPanel wp = (WrapPanel)listOrders.SelectedItem;
            if (wp != null)
            {
                int id = Convert.ToInt32(wp.Uid);

                order = orders.Find(x => x.id == id);
                if (order != null)
                {
                    Discription.Text = order.Описание_проблемы;

                    if (order.Сотрудники != null)
                        Master.Content = order.Сотрудники1.Фамилия + " " + order.Сотрудники1.Имя;
                    else
                        Master.Content = "Не назначен";
                }
            }

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)//Изменить описание
        {
            if (Discription.IsReadOnly == true)
            {
                Discription.IsReadOnly = false;
            }
            else
            {
                if (Discription.Text != "")
                {
                    Заявки orderNew = db.Заявки.FirstOrDefault(x => x.id == order.id);
                    orderNew.Описание_проблемы = Discription.Text;
                    db.SaveChanges();
                    Discription.IsReadOnly = true;
                    MessageBox.Show("Описание успешно измененно!");
                }
                else
                    MessageBox.Show("Введите описание!");
            }
        }
    }
}
